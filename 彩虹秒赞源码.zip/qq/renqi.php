<?php
//刷空间人气

$maxnum = 10; //每QQ最大刷人气次数

header("content-Type: text/html; charset=utf-8");

require_once 'cron.inc.php';
require_once "qzone.class.php";

$size = 5; //每次访问的数量

$log_file = './temp/visit.txt';
if(file_exists($log_file)){
	$log = explode(",",file_get_contents($log_file));
}else{
	$log = array();
}

$qq=isset($_GET['qq']) ? $_GET['qq'] : null;

if($qq){}else{echo "<font color='red'>输入不完整!<a href='javascript:history.back();'>返回重新填写</a></font>";exit;}

if($_GET['runkey']!=md5(RUN_KEY)) {
	if($islogin!=1)exit('未登录！');
	if(in_array('zyzan',$vip_func) && $isvip==0 && $isadmin==0)exit('您不是VIP，无法使用！');
}
if(OPEN_SHUA==0)exit('当前站点未开启此功能。');

$count = qzone::get_renqi($qq);
if($count===false){
	echo '请设置所有人可以访问你的空间！';
	exit;
}
elseif($count>$maxnum){
	echo '你的QQ空间人气已达到10个，请明天再来！';
	exit;
}

$result=$DB->query("select * from `".DBQZ."_qq` where status=1 order by rand() limit 50");

$count = 0;

while($row=$DB->fetch($result)){
	$record = $row['qq'].'-'.$qq;
	if(!in_array($record,$log)){
		$qzone=new qzone($row['qq'],$row['sid'],$row['skey'],$row['pskey']);
		$qzone->visitqzone($qq);
		$log[] = $record;
		echo $qzone->msg[0].'<br/>';
		$count++;
		if($count>=$size)break;
	}
}
if($count==0){
	echo '当前网站暂无可以访问空间的QQ';
	exit;
}
file_put_contents($log_file, implode(',',$log));
?>