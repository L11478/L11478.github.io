<?php
/*
 * QQ聊天气泡百变 Author:消失的彩虹海
 */
require 'qq.inc.php';

$uin=isset($_GET['qq']) ? $_GET['qq'] : null;
$skey=isset($_GET['skey']) ? $_GET['skey'] : null;

if($uin && $skey){}else{echo"<font color='red'>输入不完整!<a href='javascript:history.back();'>返回重新填写</a></font>";exit;}

$str='4271|4270|3433|3434|4171|3466|3467|4135|3719|3941|3565|4084|4083|4116|4117|4113|4112|3592|3729|3590|3591|3904|3732|3424|3772|2941|3656|3647|3022|3566|3601|3448|3447|3384|3241|3242|3247|3271|3264|2822|3139|3214|2903|3212|3103|3133|3097|3086|3087|3048|3045|3001|2982|2889|2859|500035|500023|600025|500010|2827|2826|2819|2814|2809|2792|2726|2765|2795|2669|2648|2625|2578|2575|2561|2562|2547|2531|2532|2533|2492|2507|2512|2423|2285|2279|2280|2281|2257|2210|2180|2145|2134|547|335|2001|2018|4316|3873|3563|4085|4086|3382|3263|3228|3119|3112|3096|3082|2946|2950|2908|2910|2913|2895|2880|2877|2860|2851|2843|2832|500034|600026|500011|2824|2783|2766|2767|2725|2764|2670|2668|2664|2665|2649|2650|2643|2645|2630|2626|2588|2579|2574|2553|2554|2523|2435|2195|2397|2380|2377|2363|2352|2335|2331|2327|2315|2311|2300|2298|2287|2286|2278|2270|2266|2254|2258|2218|2216|2215|2208|2181|2182|2158|2157|528|2133|368|2049|2131|233|2560|470';

$id=array_rand(explode('|',$str),1);
$gtk= getGTK($skey);
$cookie = 'pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.'; ';
$url = 'http://logic.content.qq.com/bubble/setup?uin='.$uin.'&id='.$id.'&version=4.6.0.0&platformId=1&format=json&g_tk='.$gtk.'&_='.time().'4000';
$data = get_curl($url,0,$url,$cookie);
$arr = json_decode($data,true);
if(array_key_exists('ret',$arr) && $arr['ret']==0){
	if($arr['data']['ret']==0 && $arr['data']['msg']=="ok"){
		$resultStr='更换气泡成功！';
	}elseif($arr['data']['ret']==5002){
		$resultStr='气泡更换失败！需参与活动';
	}elseif($arr['data']['ret']==2002){
		$resultStr='气泡更换失败！你不是会员';
	}else{
		$resultStr='气泡更换失败！';
	}
}elseif($arr['ret']==-100001){
	$resultStr='更换气泡失败！SKEY过期';
}else{
	$resultStr='更换气泡失败！'.$arr['msg'];
}
echo $resultStr;

function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$httpheader[] = "Accept:application/json";
	$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
	$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
	$httpheader[] = "Connection:close";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
function getGTK($skey){
	$len = strlen($skey);
	$hash = 5381;
	for($i = 0; $i < $len; $i++){
		$hash += ($hash << 5) + ord($skey[$i]);
	}
	return $hash & 0x7fffffff;//计算g_tk
}
?>