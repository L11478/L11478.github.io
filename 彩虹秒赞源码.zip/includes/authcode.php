<?php
$authcode='null';

?>