<?php
/*
 * 百度社会化登录（彩虹API中转）
 */

class Oauth{

    function __construct(){
		global $siteurl;
        $this->callback = $siteurl.'social.php';
    }

    public function login(){
		global $allapi;

        //-------生成唯一随机串防CSRF攻击
        $state = md5(uniqid(rand(), TRUE));
        $_SESSION['Oauth_state'] = $state;

        //-------构造请求参数列表
        $keysArr = array(
            "act" => "login",
			"media_type" => $_GET['type'],
            "redirect_uri" => $this->callback,
            "state" => $state
        );
		if($_GET['type']=='qqdenglu')
			$login_url = $allapi.'social/connect.php?'.http_build_query($keysArr);
		else
			$login_url = $allapi.'social/login.php?'.http_build_query($keysArr);

        header("Location:$login_url");
    }

    public function callback(){
		global $allapi;
        //--------验证state防止CSRF攻击
        if($_GET['state'] != $_SESSION['Oauth_state']){
            sysmsg("<h2>The state does not match. You may be a victim of CSRF.</h2>");
        }

        //-------请求参数列表
        $keysArr = array(
            "act" => "callback",
			"code" => $_GET['code'],
            "redirect_uri" => $this->callback
        );

        //------构造请求access_token的url
		if($_GET['type']=='qqdenglu')
			$token_url = $allapi.'social/connect.php?'.http_build_query($keysArr);
		else
			$token_url = $allapi.'social/login.php?'.http_build_query($keysArr);
        $response = get_curl($token_url);

		$arr = json_decode($response,true);

        if(isset($arr['error_code'])){
            sysmsg('<h3>error:</h3>'.$arr['error_code'].'<h3>msg  :</h3>'.$arr['error_msg']);
        }

        $_SESSION['Oauth_access_token']=$arr["access_token"];
        $_SESSION['Oauth_social_uid']=$arr["social_uid"];
        return $arr;
    }
}
