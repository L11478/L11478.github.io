<?php
if(!defined('IN_CRONLITE'))exit();
if($islogin==1)
{
	$qq=daddslashes($_GET['qq']);
	$groupid=daddslashes($_GET['groupid']);
	$start=isset($_GET['start'])?intval($_GET['start']):0;
	$end=$start+40;

	if(!$cookie_qun=$_SESSION[$qq.'_cookie_qun'])exit('{"code":-1,"msg":"请刷新页面重试"}');
	preg_match('/skey=(.{10});/',$cookie_qun,$skey_qun);
	$gtk_qun = getGTK($skey_qun[1]);

	$url='http://qun.qq.com/cgi-bin/qun_mgr/search_group_members';
	$post='gc='.$groupid.'&st='.$start.'&end='.$end.'&sort=0&bkn='.$gtk_qun;
	$ua='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
	$data = get_curl($url,$post,'http://qun.qq.com/member.html',$cookie_qun,0,$ua);
	$arrs = json_decode($data,true);
	//print_r($arrs);exit;
	if (!$arrs) {
		exit('{"code":-1,"msg":"QQ群成员获取失败！"}');
	}elseif ($arrs["ec"] == 1) {
		exit('{"code":-1,"msg":"SKEY已过期！"}');
	}elseif ($arrs["ec"]!=0){
		exit('{"code":-1,"msg":"QQ群成员获取失败！'.$arrs['em'].'"}');
	}
	$data = array();
	$data['code'] = 0;
	$data['count'] = $arrs['count'];
	$data['mems'] = $arrs['mems'];
	if($end<$arrs['count'])$data['start'] = $end+1;
	else $data['start'] = 0;
	exit(json_encode($data));
}else{
	exit('{"code":-3,"msg":"登录失败，可能是密码错误或者身份失效了，请重新登录！"}');
}