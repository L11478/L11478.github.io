﻿<?php 
$title="用户注册";
include_once(TEMPLATE_ROOT."head2.php");
if($verifyswich==1)
$displyver='<div class="form-group"><input type="text" name="verify" class="form-control" style="max-width: 55%;display:inline-block;vertical-align:middle;" placeholder="输入验证码" required>&nbsp;<img title="点击刷新" src="verifycode.php" onclick="this.src=\'verifycode.php?\'+Math.random();" style="max-height:42px;vertical-align:middle;" class="img-rounded"></div>';
else $displyver='';
?>
<div class="yunyan_box">
<div class="yunyan_logo">
        <i class="fa fa-thumbs-up"></i>
        <strong><?php echo $conf['sitename']?></strong></div>
			<form action="index.php?mod=reg" method="POST">
			<input name="my" type="hidden" value="reg">
				<div class="form-group">
					<input name="user" type="text" class="form-control" placeholder="用户名" required="">
				</div>
				<br>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-6">
							<input name="pass" type="password" placeholder="密码" class="form-control" required="">
						</div>
						<div class="col-sm-6">
							<input name="pass2" type="password" placeholder="重复密码" class="form-control" required="">
						</div>
					</div>
				</div>
				<br>
				<div class="form-group">
					<input name="qq" type="text" class="form-control" placeholder="QQ：用于显示头像及找回密码" required="">
				</div>
				<br>
				<?php if($conf['zc_mail']==1){?>
				<div class="form-group">
					<input name="email" type="email" class="form-control" placeholder="邮箱：用于找回密码及SID失效提醒" required/>
				</div>
				<br>
				<?php }?>
				<?php echo $displyver?><br>
				
				<input href="index.html" value="注册" name="submit" style="width: 100%; opacity: 1; pointer-events: auto;" type="submit" data-form-sbm="1489324971010.4194">
				<br>
				<br>
				<br>
				<div class="row push">
          <div class="col-xs-6">
            <a href="index.php?mod=login" class="btn btn-sm btn-info btn-block">
              <i class="fa fa-sign-out"></i> 返回登陆</a>
          </div>
          <div class="col-xs-6">
            <a href="index.php?mod=findpwd" class="btn btn-sm btn-primary btn-block">
              <i class="fa fa-info-circle"></i> 忘记密码</a>
          </div>
        </div>
	</form>
</div>
<div class="clearfix"></div>
</body>
</html>