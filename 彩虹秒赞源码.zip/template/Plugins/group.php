<?php
 /*
　* 提取群成员
*/ 
if(!defined('IN_CRONLITE'))exit();
$title="提取群成员";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq='.$_GET['qq'].'">'.$_GET['qq'].'</a></li>
<li class="active"><a href="#">提取群成员</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-8 col-sm-10 col-xs-12 center-block" role="main">';

if($islogin==1){
$qq=daddslashes($_GET['qq']);
if(!$qq) {
	showmsg('参数不能为空！');
}
$row=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
if($row['uid']!=$uid && $isadmin==0) {
	showmsg('你只能操作自己的QQ哦！');
}
if ($row['status']!=1) {
	showmsg('SKEY已过期！');
}
if ($row['status2']!=1) {
	showmsg('superkey已过期！');
}
$skey=$row['skey'];
$pskey=$row['pskey'];
$superkey=$row['superkey'];

$gtk = getGTK($skey);
$cookie='pt2gguin=o0'.$qq.'; uin=o0'.$qq.'; skey='.$skey.'; p_uin=o0'.$qq.'; p_skey='.$pskey.';';
$ua='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
$url='http://qun.qzone.qq.com/cgi-bin/get_group_list?callbackFun=_GetGroupPortal&uin='.$qq.'&ua=Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64%3B%20rv%3A25.0)%20Gecko%2F20100101%20Firefox%2F25.0&random=0.946546206453239&g_tk='.$gtk;
$data = get_curl($url,0,'http://qun.qzone.qq.com/group',$cookie,0,$ua);
preg_match('/_GetGroupPortal_Callback\((.*?)\)\;/is',$data,$json);
$arr = json_decode($json[1],true);
//print_r($arr);exit;
if (!$arr) {
	showmsg('QQ群列表获取失败！');
}elseif ($arr["code"] == -3000) {
	showmsg('SKEY已过期！');
}

if(!$cookie_qun=$_SESSION[$qq.'_cookie_qun']){
	include ROOT.'qq/qqsign.class.php';
	$qzone=new qqsign($qq,$sid,$skey);
	$cookie_qun=$qzone->qqqun($superkey);
	if(!$cookie_qun){
		showmsg('superkey已失效！');
	}
	$_SESSION[$qq.'_cookie_qun']=$cookie_qun;
}
?>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">提取群成员</h3>
	</div>
	<div class="panel-body" align="left">
		<input type="hidden" name="cookie_qun" value="<?php echo $cookie_qun ?>">
		<div class="form-group">
		<div class="input-group"><div class="input-group-addon">QQ群列表</div>
		<input type="hidden" name="mod" value="group">
		<input type="hidden" name="qq" value="<?php echo $qq ?>">
		<select name="groupid" class="form-control">
			<?php
			foreach($arr['data']['group'] as $row) {
				echo '<option value="'.$row['groupid'].'" '.($groupid==$row['groupid']?'selected="selected"':NULL).'>'.$row['groupid'].'_'.$row['groupname'].'</option>';
			}
			?>
			</select>
		</div></div>
		<div class="form-group">
		<button type="button" class="btn btn-primary btn-block" onclick="showlist()">提取群成员</button>
		</div>
	</div>
</div>
<div class="panel panel-success" style="display:none;" id="memslist">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">群成员列表（<span id="mem_count"></span>）</h3>
	</div>
	<table class="table table-bordered">
		<tbody id="datalist">
		</tbody>
	</table>
</div>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script>
<script src="//lib.baomitu.com/FileSaver.js/2014-11-29/FileSaver.min.js"></script>
<script>
function showlist(){
	var qq = $("input[name='qq']").val();
	var groupid = $("select[name='groupid']").val();
	if(groupid == ''){
		layer.alert('请选择一个QQ群');
		return false;
	}
	$("#datalist").empty();
	$("#datalist").html('<tr><td><span style="color:silver;"><b>ＱＱ</b></span></td><td><span style="color:silver;"><b>昵称</b></span></td></tr><tr><td colspan="2" align="center"><a href="javascript:outputmem()" pjax="no">导出群成员列表为TXT</a></td></tr>');
	memslist(qq,groupid)
}
function memslist(qq,groupid,start){
	start = start || 0;
	if(start>0){
		var mem_count = $("#mem_count").html();
		var ii = layer.msg('正在加载群成员('+(start-1)+'/'+mem_count+')', {icon: 16,shade: 0.01,time: 15000});
	}else{
		var ii = layer.msg('正在加载群成员', {icon: 16,shade: 0.01,time: 15000});
	}
	$.ajax({
		type : 'GET',
		url : 'ajax.php?mod=group&qq='+qq+'&groupid='+groupid+'&start='+start,
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				$("#memslist").show();
				$("#mem_count").html(data.count);
				$.each(data.mems, function(i, item){
					$("#datalist").append('<tr><td uin="'+item.uin+'" class="uins"><a href="tencent://message/?uin='+item.uin+'&amp;Site=&amp;Menu=yes">'+item.uin+'</a></td><td>'+item.nick+'</td></tr>');
				});
				if(data.start > 0){
					memslist(qq,groupid,data.start)
				}
			}else{
				layer.alert(data.msg, {icon:2});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
function outputmem() {
	var groupid = $("select[name='groupid']").val();
	var txt = "";
	$(".uins").each(function(){
		txt += $(this).attr('uin') + "\r\n";
	});
	var fileName = "group_member_"+groupid+".txt";
	var blob = new Blob([txt], {type: "text/plain;charset=utf-8"});
	saveAs(blob, fileName);
}
</script>
<?php
}
else{
showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>