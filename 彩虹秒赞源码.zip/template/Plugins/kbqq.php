<?php
 /*
　* 空白头像/昵称
*/ 
if(!defined('IN_CRONLITE'))exit();
$title="空白头像/昵称";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq='.$_GET['qq'].'">'.$_GET['qq'].'</a></li>
<li class="active"><a href="#">空白头像/昵称</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-8 col-sm-10 col-xs-12 center-block" role="main">';

if($islogin==1){
$qq=daddslashes($_GET['qq']);
if(!$qq) {
	showmsg('参数不能为空！');
}
$row=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
if($row['uid']!=$uid && $isadmin==0) {
	showmsg('你只能操作自己的QQ哦！');
}
if ($row['status']!=1) {
	showmsg('SKEY已过期！');
}
$sid=$row['sid'];
$skey=$row['skey'];
$pskey=$row['pskey'];

function getGTK2($skey){
	$salt = 5381;
	$md5key = 'tencentQQVIP123443safde&!%^%1282';
	$hash = array();
	$hash[] = ($salt << 5);
	for($i = 0; $i < strlen($skey); $i ++)
	{
		$ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
		$ASCIICode = hexdec(bin2hex($ASCIICode));
		$hash[] = (($salt << 5) + $ASCIICode);
		$salt = $ASCIICode;
	}
	$md5str = md5(implode($hash) . $md5key);
	return $md5str;
}
if(isset($_GET['act']) && $_GET['act']=='setface'){
	$cookie="uin=o0".$qq."; skey=".$skey.";";
	$url = "https://face.qq.com/client/uploadflash.php";
	$param = '--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="is_set"'."\r\n"."\r\n".'1'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="is_share"'."\r\n"."\r\n".'0'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="format"'."\r\n"."\r\n".'png'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="name"'."\r\n"."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="vip_level"'."\r\n"."\r\n".'0'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="isHD"'."\r\n"."\r\n".'false'."\r\n".'Content-Disposition: form-data; name="catId"'."\r\n"."\r\n".'0'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="cmd"'."\r\n"."\r\n".'set_and_share_face'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="Filename"'."\r\n"."\r\n".'image100*100'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="Upload"'."\r\n"."\r\n".'Submit Query'."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl'."\r\n".'Content-Disposition: form-data; name="Filedata[]"; filename="image100*100"'."\r\n".'Content-Type: application/octet-stream'."\r\n"."\r\n".file_get_contents("http://qqpublic.qpic.cn/qq_public/0/0-3083588061-157B50D7A4036953784514241D7DDC19/0")."\r\n".'--dfqrjvqousilvsjdoialahdhkrxxbfrl--';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	$header[] = "Content-Type: multipart/form-data; boundary=dfqrjvqousilvsjdoialahdhkrxxbfrl";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	$return = curl_exec($ch);
	curl_close($ch);
	preg_match_all("/\"result\":(.*),/iUs",$return,$result);
	preg_match_all("/\"result\":(.*)}/iUs",$return,$result_no);
	if($result[1][0]=="0"){
		$msg='<div class="alert alert-success"><center>QQ透明头像设置成功！</center></div>';
	}elseif($result_no[1][0]=="1001"){
		$msg='<div class="alert alert-danger"><center>透明头像设置失败请尝试重新登录</center></div>';
	}elseif($result_no[1][0]=="1002"){
		$msg='<div class="alert alert-danger"><center>非QQ会员，无法设置透明头像！</center></div>';
	}else{
		$msg='<div class="alert alert-danger"><center>透明头像设置失败请尝试重新登录</center></div>';
	}
}elseif(isset($_GET['act']) && $_GET['act']=='setnick'){
	$nickname=$_GET['nickname'];
	$cookie='pt2gguin=o0'.$qq.'; uin=o0'.$qq.'; skey='.$skey.'; p_skey='.$pskey.'; p_uin=o0'.$qq.';';
	$url="https://w.qzone.qq.com/cgi-bin/user/cgi_apply_updateuserinfo_new?g_tk=".getGTK($pskey)."";
	$data="qzreferrer=https%3A%2F%2Fctc.qzs.qq.com%2Fqzone%2Fv6%2Fsetting%2Fprofile%2Fprofile.html%3Ftab%3Dbase&nickname=".$nickname."&emoji=&sex=1&birthday=2015-01-01&province=0&city=PAR&country=FRA&marriage=6&bloodtype=5&hp=0&hc=PAR&hco=FRA&career=&company=&cp=0&cc=0&cb=&cco=0&lover=&islunar=0&mb=1&uin=".$qq."&pageindex=1&nofeeds=1&fupdate=1&format=json";
	$return=get_curl($url,$data,$url,$cookie);
	$arr = json_decode($return,true);
	if(@array_key_exists('code',$arr) && $arr['code']==0){
		$msg='<div class="alert alert-success"><center>QQ更换昵称成功！</center></div>';
	}else{
		$msg='<div class="alert alert-danger"><center>昵称'.$arr['message'].'</center></div>';
	}
}
?>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">空白头像/昵称</h3>
	</div>
	<div class="panel-body" align="center">
	<a class="btn btn-danger" href="./index.php?mod=kbqq&qq=<?php echo $qq?>&act=setface">一键设置透明头像</a><hr/>
	<form action="./index.php" method="get">
		<input type="hidden" name="mod" value="kbqq">
		<input type="hidden" name="qq" value="<?php echo $qq?>">
		<input type="hidden" name="act" value="setnick">
		<div class="form-group">
        <div class="input-group">
		<div class="input-group-addon" id="inputname">新昵称</div>
		<input type="nickname" name="nickname" class="form-control" value='<?php echo isset($_GET['nickname'])?$_GET['nickname']:'' ?>' required>
		 </div>
        </div>
		<input type="submit" class="btn btn-success btn-block" value="确定">
	</form>
	<br/><?php echo $msg?>
	</div>
</div>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">使用说明</h3>
	</div>
	<div class="panel-body" align="left">
		<p style="color:blue">一键设置透明头像&空白昵称
<br/>空白昵称只需输入空格即可
		</p>
	</div>
</div>
<?php
}
else{
showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>