<?php
if(!defined('IN_CRONLITE'))exit();

$title='解散群';
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq='.$_GET['qq'].'">'.$_GET['qq'].'</a></li>
<li class="active"><a href="#">解散群</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-8 col-sm-10 col-xs-12 center-block" role="main">';

if($islogin==1){

$qq=daddslashes($_GET['qq']);
if(!$qq) {
	showmsg('参数不能为空！');
}
$row=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
if($row['uid']!=$uid && $isadmin==0) {
	showmsg('你只能操作自己的QQ哦！');
}
if ($row['status']!=1) {
	showmsg('SKEY已过期！');
}
$superkey=$row['superkey'];

if(!$cookie_qqid=$_SESSION[$qq.'_cookie_qqid']){
	include ROOT.'qq/qqsign.class.php';
	$qzone=new qqsign($qq,$sid,$skey);
	$cookie_qqid=$qzone->qqid($superkey);
	if(!$cookie_qqid){
		showmsg('superkey已失效！');
	}
	$_SESSION[$qq.'_cookie_qqid']=$cookie_qqid;
}

$resultarr = array(11=>'需要验证码', 13=>'号码异常，暂时不允许解散', 15=>'为了企业信息安全，请登录企业帐户中心进行解散操作。', 16=>'公益群暂不支持解散。2891387758', 17=>'该群被转让不足28天，暂时还不能解散。', 25=>'付费2000人群不可解散。', 51=>'您的群已绑定了教育机构，如需进行此操作，请先与机构解绑。');

if(isset($_GET['group']))
{
	$group = daddslashes($_GET['group']);
	$gtk = getGTK($row['skey']);
	$url = 'https://id.qq.com/qun/dismiss_group';
	$referrer = 'https://id.qq.com/proxy.html';
	$post = 'vc=undefined&gc='.$group.'&uin='.$qq.'&s=1&bkn='.$gtk;
	$data = get_curl($url,$post,$referrer,$cookie_qqid);
	$arr = json_decode($data,true);
	if (@array_key_exists('ec',$arr) && $arr['ec']==0) {
		showmsg('解散群成功！',1);
	}elseif($arr['ec']==1){
		showmsg('解散群失败，原因：SKEY已失效',3);
	}elseif(array_key_exists($arr['ec'],$resultarr)){
		showmsg($resultarr[$arr['ec']],3);
	}else{
		showmsg('解散群失败，可能非群主或群不存在。返回信息：'.$data,3);
	}
}
?>
<div class="panel panel-info">
<div class="panel-heading"><h3 class="panel-title">解散群（支持解散被封的群）</h3></div>
<div class="panel-body">
<form action="index.php" method="GET" role="form">
<input type="hidden" name="mod" value="dismissgroup">
<input type="hidden" name="qq" value="<?php echo $qq?>">
<div class="list-group-item">
<div class="input-group">
<div class="input-group-addon">ＱＱ群号</div>
<input type="text" class="form-control" name="group" value="<?php echo $group?>" placeholder="请输入群号" required>
</div>
</div>
<div class="list-group-item">
<input type="submit" class="btn btn-primary btn-block" value="立即解散">
</div>
</form>
</div>
</div>
<?php
}else{
showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}

include TEMPLATE_ROOT."foot.php";
?>