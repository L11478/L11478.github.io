<?php
/*支付接口订单监控文件
说明：用于请求支付接口订单列表，同步未通知到本站的订单，防止漏单。
监控频率建议5分钟一次
监控地址：/cron/epaytask.php?key=监控密钥
注意：千万不要监控太快或使用多节点监控！！！否则会被支付接口自动屏蔽IP地址
*/

if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
include_once("../includes/cron.inc.php");

@header('Content-Type: text/html; charset=UTF-8');

if($conf['epay_pid'] && $conf['epay_key']){
	$cron_lasttime = $DB->get_column("SELECT v FROM ".DBQZ."_config WHERE k='cron_lasttime' limit 1");
	if(time()-strtotime($cron_lasttime)<30)exit('ok');
	$trade_no = date("YmdHis",strtotime($cron_lasttime)).'000';
	$limit = $DB->count("SELECT count(*) FROM ".DBQZ."_pay WHERE orderid>'$trade_no'");
	if($limit<1)exit('ok');
	if($limit>50)$limit=50;
	$payapi=pay_api(true);
	$data = get_curl($payapi.'api.php?act=orders&limit='.$limit.'&pid='.$conf['epay_pid'].'&key='.$conf['epay_key']);
	$arr = json_decode($data, true);
	if($arr['code']==1){
		foreach($arr['data'] as $content){
			if($content['status']==1){
				$out_trade_no = $content['out_trade_no'];
				$srow=$DB->get_row("SELECT * FROM ".DBQZ."_pay WHERE orderid='{$out_trade_no}' limit 1");
				if($srow && $srow['status']==0){
					$uid=$srow['uid'];
					$DB->query("update `".DBQZ."_pay` set `status` ='1',`endtime` ='$date' where `orderid`='$out_trade_no'");
					$msg = 'OK';
					$row=$DB->get_row("select * from ".DBQZ."_user where userid='".$uid."' limit 1");
					if($row['vip']==1 && strtotime($row['vipdate'])>time() || $row['vip']==2){
						$isvip=1;
					}else{
						$isvip=0;
					}
					getshop($srow['shopid'],$srow['qq'],$msg);
					echo '已成功补单:'.$out_trade_no.'<br/>';
				}
			}
		}
		saveSetting('cron_lasttime',$date);
		exit('ok');
	}else{
		exit($arr['msg']);
	}
}else{
	exit('未配置易支付信息');
}