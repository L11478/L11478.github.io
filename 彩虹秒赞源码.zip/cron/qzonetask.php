<?php
/*QQ空间任务监控文件*/
@chdir(dirname(__FILE__));
include_once("../includes/cron.inc.php");
//$sysid=isset($_GET['sys'])?$_GET['sys']:1;
$sysid=1;
$infoid=$sysid+300;
$sleep2=$conf['sleep2']<10?10:$conf['sleep2'];
$selfname='cron/qzonetask.php';

if(isset($_GET['multi']))
{ //开始运行每个线程
	$start=intval($_GET['start']);
	$num=intval($_GET['num']);
	$rs=$DB->query("select * from ".DBQZ."_qqjob where sign=0 and zt=0 and fail=0 and nexttime<=$time order by nexttime asc limit {$start},{$num}");
}
elseif($conf['runmodol']==0)
{ //启动多线程
$nump=$DB->count("select count(*) from ".DBQZ."_qqjob WHERE sign=0 and zt=0 and fail=0 and nexttime<=$time");
$xz=ceil($nump/$size);
if($xz>1){
	for($i=0;$i<=$xz;$i++){
		$start=$i*$size;
		curl_run($siteurl.$selfname.'?key='.$_GET['key'].'&multi=on&start='.$start.'&num='.$size);
	}
	exit("Successful opening of {$xz} threads!");
}else{
	$rs=$DB->query("select * from ".DBQZ."_qqjob where sign=0 and zt=0 and fail=0 and nexttime<=$time order by nexttime asc");
}
}
else
{ //强制单线程
	$nump=$DB->count("select count(*) from ".DBQZ."_qqjob WHERE sign=0 and zt=0 and fail=0 and nexttime<=$time");
	$xz=ceil($nump/$size);
	$shu=$DB->get_row("SELECT * FROM ".DBQZ."_info WHERE sysid='$infoid' limit 1");
	$shu=$shu['times'];
	$up_shu=$shu+1;
	if($shu>=$xz)
	{
		$DB->query("update ".DBQZ."_info set times='1' where sysid='$infoid'");
		$shu=0;
	}
	else
	{
		$DB->query("update ".DBQZ."_info set times='".$up_shu."' where sysid='$infoid'");
	}
	$shu=$shu*$size;
	$rs=$DB->query("select * from ".DBQZ."_qqjob where sign=0 and zt=0 and fail=0 and nexttime<=$time order by nexttime asc limit $shu,$size");
}

while ($row = $DB->fetch($rs)) {
	if($row['nexttime']>$time)continue;

	$id =$row['jobid'];
	if(!$qqTaskNames[$row['type']]){
		$DB->query("delete from `".DBQZ."_qqjob` where `jobid`='$id'");
		continue;
	}

	$qqjob=qqjob_decode($row['qq'],$row['type'],$row['method'],$row['data']);
	if($qqjob['status']=='no'){
		$DB->query("update `".DBQZ."_qqjob` set `fail`=1 where `jobid`='$id'");
		continue;
	}

	$day=date("Ymd");
	if($row['day']!=$day && $conf['jifen']==1 && $rules[4]!=0){ //扣除虚拟币
		if(coin_check($row['uid'],$rules[4],$row['type'],$row['qq'])){
			$DB->query("update ".DBQZ."_qqjob set day='$day' where jobid='$id'");
		}else{
			$DB->query("update ".DBQZ."_qqjob set zt='1' where jobid='$id'");
			continue;
		}
	}

	$url=$qqjob['url'].'&runkey='.md5(RUN_KEY).'&backurl='.urlencode($siteurl);

	$curl=curl_init();
	$urlarr = parse_url($url);
	if($conf['localcron']==1 && $urlarr['host']==$_SERVER['HTTP_HOST']){
		$url=str_replace('http://'.$_SERVER['HTTP_HOST'].'/','http://127.0.0.1:80/',$url);
		$url=str_replace('https://'.$_SERVER['HTTP_HOST'].'/','https://127.0.0.1:443/',$url);
		$url.='&localcron=1';
		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Host: '.$_SERVER['HTTP_HOST']));
	}elseif($conf['localcron']==2 && $urlarr['host']==$_SERVER['HTTP_HOST'] && isset($_SERVER['SERVER_ADDR'])){
		$url=str_replace('http://'.$_SERVER['HTTP_HOST'].'/','http://'.$_SERVER['SERVER_ADDR'].':'.$_SERVER['SERVER_PORT'].'/',$url);
		$url=str_replace('https://'.$_SERVER['HTTP_HOST'].'/','https://'.$_SERVER['SERVER_ADDR'].':443/',$url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Host: '.$_SERVER['HTTP_HOST']));
	}
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,5);
	curl_setopt($curl,CURLOPT_TIMEOUT,1);
	curl_setopt($curl,CURLOPT_NOBODY,1);
	curl_setopt($curl,CURLOPT_NOSIGNAL,true);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_AUTOREFERER,1);
	curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,false);
	curl_exec($curl);
	curl_close($curl);

	if(in_array($row['type'],$qqSignTasks))$interval=18000;
	elseif(in_array($row['type'],$qqGuajiTasks))$interval=3600;
	elseif(in_array($row['type'],$qqLimitTasks))$interval=600;
	elseif($row['type']=='zan')$interval=$sleep2;
	elseif($row['type']=='webqq')$interval=50;
	elseif($row['pl']<30)$interval=30;
	else $interval=$row['pl'];

	if($row['start']>$t)
		$nexttime=strtotime('+'.($row['start']-$t).' hours');
	elseif($row['stop']<$t)
		$nexttime=strtotime('+'.(24-$row['stop']+$row['start']).' hours');
	else
		$nexttime=$time+$interval;
	$time = time();
	$DB->query("update `".DBQZ."_qqjob` set `times`=`times`+1,`lasttime`='$time',`nexttime`='$nexttime' where `jobid`='$id'");
}

$DB->query("update `".DBQZ."_info` set `last`='$date' where sysid='$infoid'");
$DB->query("update `".DBQZ."_info` set `times`=`times`+1,`last`='$date' where sysid='0'");
$DB->close();

echo '<head><title>success in run</title></head>';
echo $date;
?>